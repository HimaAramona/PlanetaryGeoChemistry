%This script will calculate ocean areal coverage for the nominal model
%using the f_water abundance, and assuming a fixed ocean depth of 4500 m.

G = 6.67384e-11; %m^3/kg/s^2
vars = {'t','T','Rp','Mp'};
load('1Mearth.mat',vars{:});
t1 = t;T1 = T;Rp1 = Rp;g1 = G * Mp / Rp^2;
load('5Mearth.mat',vars{:});
t5 = t;T5 = T;Rp5 = Rp;g5 = G * Mp / Rp^2;
clear t T

level1 = [-7.0 -6.0 -5.0 -4.0 -3.0 -2.0 -1.0 0.0 1.0 2.0 3.0 4.0]*1e3;
delta1 = level1(2) - level1(1);
level5 = level1 *(g1/g5);
delta5 = level5(2) - level5(1);
SAfract = [1.0 16.4 23.2 13.9 4.8 3.0 8.5 20.9 4.5 2.2 1.1 0.5]/100;
SA1 = 5.1e14;
SA5 = 1.2e15;
rho = 1e3;
surfacewater1 = (T1(1,2)-T1(:,2));
surfacewater5 = (T5(1,2)-T5(:,2));
watervolume1 = surfacewater1/rho;
watervolume5 = surfacewater5/rho;
depth1 = zeros(length(watervolume1),1);
depth5 = zeros(length(watervolume5),1);

calcvolume = 0;
for i = 2:length(watervolume1)
    for j = 1:length(level1);
        calcvolume = calcvolume + delta1 * sum(SAfract(1:j))*SA1;
        if calcvolume > watervolume1(i)
            calcvolume = calcvolume - delta1 * sum(SAfract(1:j))*SA1;
            difference = watervolume1(i) - calcvolume;
            depth1(i)  = difference / sum(SAfract(1:j))/SA1 + (j-1) * delta1;
            break
        elseif calcvolume < watervolume1(i) && j == length(level1);
            difference = watervolume1(i) - calcvolume;
            depth1(i) = difference / SA1 + level1(j)-level1(1);
        end
    
    end
    depth1(i) = depth1(i) + level1(1);
    calcvolume = 0;
end
            
calcvolume = 0;
for i = 1:length(watervolume5)
    for j = 1:length(level5);
        calcvolume = calcvolume + delta5 * sum(SAfract(1:j))*SA5;
        if calcvolume > watervolume5(i)
            calcvolume = calcvolume - delta5 * sum(SAfract(1:j))*SA5;
            difference = watervolume5(i) - calcvolume;
            depth5(i)  = difference / sum(SAfract(1:j))/SA5 + (j-1) * delta5;
            break
        elseif calcvolume < watervolume5(i) && j == length(level5);
            difference = watervolume5(i) - calcvolume;
            depth5(i) = difference / SA5 + level5(j)-level5(1);
        end
    
    end
    calcvolume = 0;
    depth5(i) = depth5(i) + level5(1);

end



figure;
plot(t1/1e6,depth1(:,1)/1e3,'b',t5/1e6,depth5(:,1)/1e3,'b--');
title('Ocean depth');
legend('1 M_{\oplus}','5 M_{\oplus}');
xlabel('time (Myrs)');
ylabel('ocean depth');


