function nuc = viscosity_top(temp,P, rho_m);
%This function calculates the viscosity in the CMB boundary layer for
%perovskite using the average temperature of the boundary layer. The
%pressure is calculated using Rp and Rc.Parameterization is taken from
%Stamenkovic et al. (2012)


%pressure in Pa
% Pcmb = rho_m * g * (Rp - Rc);

%viscosity parameters
nu0 = 1e21;%Pa s
Ea = 300e3;% J/mole
R = 8.314; % J/mole/K
%effective activation volume m^3/mole
V_eff = 2.5e-6;
% V_eff = 0e0;

Tref = 1600;
Pref = 0;

etac = nu0 * exp((Ea/R) * (1/temp - 1/Tref) + (1/R) * (P * V_eff / temp));
nuc = etac / rho_m;
end
