load('1Mearth.mat')
Rp = 6371e3;
g = 9.82;
avgfact = 1.19;
z = (0:1e3:300e3)'; %meters
rho_m = 4480;
press = rho_m * g * z/1e9; %in GPa

for i = 1:length(T(:,1));
    [Tprofile, Tsolidus,Tsol_wet,Tliquidus,Tliq_wet] = ...
        temperatureprofiles(T(i,1),Db(i),qm(i),f_water(i),Rp,g,avgfact);
    plot(z/1e3,Tprofile,'k',z/1e3,Tsolidus,'r',z/1e3,Tsol_wet,'r:',z/1e3,Tliquidus,'b',...
        z/1e3,Tliq_wet,'b:');
    pause(1)
end
