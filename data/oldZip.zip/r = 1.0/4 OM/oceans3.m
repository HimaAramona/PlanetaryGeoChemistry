% This script calculates the maximum ocean depth assuming 90% ocean
% coverage using the equations of Cowan & Abbot (2014) (eqn. 15). 

G = 6.67384e-11; %m^3/kg/s^2
Me = 5.97e24;%mass of earth
Mo = 1.39e21;%mass of Earth ocean
Xm = 0.675; %mass fraction of mantle
Xo = Mo/Me; %mass fraction surface oceans of Earth
fb = 1.3;%0.9/0.7 = ratio of super-Earth ocean area/Earth ocean area
g = 9.8;
rho = 1e3;
vars = {'t','T','Rp','Mp'};
load('1Mearth.mat',vars{:});
t1 = t;T1 = T;Rp1 = Rp;g1 = G * Mp / Rp^2;
load('2Mearth.mat',vars{:});
t2 = t;T2 = T;Rp2 = Rp;g2 = G * Mp / Rp^2;
load('3Mearth.mat',vars{:});
t3 = t;T3 = T;Rp3 = Rp;g3 = G * Mp / Rp^2;
load('5Mearth.mat',vars{:});
t5 = t;T5 = T;Rp5 = Rp;g5 = G * Mp / Rp^2;
clear t T
gravity = [g1 g2 g3 g5];


depth = 4000; %average depth of Earth's oceans
SA1 = 5.1e14;SA2 = 7.5e14;SA3 = 9.2e14;SA5 = 1.2e15;
surfacewater1 = (T1(1,2)-T1(:,2)) ;
surfacewater2 = (T2(1,2)-T2(:,2));
surfacewater3 = (T3(1,2)-T3(:,2));
surfacewater5 = (T5(1,2)-T5(:,2));
maxdepth = 11.4 .* (gravity/g).^-1 *1000;
arealfrac1 = surfacewater1 / rho / maxdepth(1) / SA1;
arealfrac2 = surfacewater2 / rho / maxdepth(2) / SA2;
arealfrac3 = surfacewater3 / rho / maxdepth(3) / SA3;
arealfrac5 = surfacewater5 / rho / maxdepth(4) / SA5;

figure;
plot(t1/1e6,arealfrac1,'b',t2/1e6,arealfrac2,'b:',t3/1e6,arealfrac3,'b-.',...
    t5/1e6,arealfrac5,'b--');
title('Minimum surface area coverage')
legend('1 M_{\oplus}','2 M_{\oplus}','3 M_{\oplus}','5 M_{\oplus}');
xlabel('time (Myrs)');
ylabel('surface area fraction');


