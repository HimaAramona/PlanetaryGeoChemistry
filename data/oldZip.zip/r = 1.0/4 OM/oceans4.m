% This script calculates the maximum ocean depth assuming 90% ocean
% coverage using the equations of Cowan & Abbot (2014) (eqn. 15). 

G = 6.67384e-11; %m^3/kg/s^2
Me = 5.97e24;%mass of earth
Mo = 1.39e21;%mass of Earth ocean
Xm = 0.675; %mass fraction of mantle
Xo = Mo/Me; %mass fraction surface oceans of Earth
fb = 1.3;%0.9/0.7 = ratio of super-Earth ocean area/Earth ocean area
g = 9.8;
vars = {'t','T','Rp','Mp'};
load('1Mearth.mat',vars{:});
t1 = t;T1 = T;Rp1 = Rp;g1 = G * Mp / Rp^2;
load('2Mearth.mat',vars{:});
t2 = t;T2 = T;Rp2 = Rp;g2 = G * Mp / Rp^2;
load('3Mearth.mat',vars{:});
t3 = t;T3 = T;Rp3 = Rp;g3 = G * Mp / Rp^2;
load('5Mearth.mat',vars{:});
t5 = t;T5 = T;Rp5 = Rp;g5 = G * Mp / Rp^2;
clear t T


depth = 4000; %average depth of Earth's oceans
SA1 = 5.1e14;SA2 = 7.5e14;SA3 = 9.2e14;SA5 = 1.2e15;
surfacewater1 = (T1(1,2)-T1(:,2))/ (Xm * 1 * Me) ;
surfacewater2 = (T2(1,2)-T2(:,2))/ (Xm * 2 * Me);
surfacewater3 = (T3(1,2)-T3(:,2)) / (Xm * 3 * Me);
surfacewater5 = (T5(1,2)-T5(:,2)) / (Xm * 5 * Me);
depth1 = depth/11400 * (g1/g)^2* surfacewater1 / fb / Xo;
depth2 = depth/11400 * (g1/g2)^2 *surfacewater2 / fb / Xo;
depth3 = depth/11400 * (g1/g3)^2 * surfacewater3 / fb / Xo;
depth5 = depth/11400 * (g1/g5)^2 * surfacewater5 / fb / Xo;


figure;
plot(t1/1e6,depth1,'b',t2/1e6,depth2,'b:',t3/1e6,depth3,'b-.',...
    t5/1e6,depth5,'b--');
title('Ocean depth for 90% surface coverage');
legend('1 M_{\oplus}','2 M_{\oplus}','3 M_{\oplus}','5 M_{\oplus}');
xlabel('time (Myrs)');
ylabel('ocean depth/max ocean depth');


