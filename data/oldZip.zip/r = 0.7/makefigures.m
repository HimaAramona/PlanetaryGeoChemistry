vars = {'t','T','f_water','qm','Db','uc','Dhyd','Dmelt','avgfact'};
load('1Mearth.mat',vars{:});
t1=t;T1=T;f_water1=f_water;qm1=qm;Db1=Db;uc1=uc;Dhyd1=Dhyd;Dmelt1=Dmelt;avgfact1=avgfact;
load('2Mearth.mat',vars{:});
t2=t;T2=T;f_water2=f_water;qm2=qm;Db2=Db;uc2=uc;Dhyd2=Dhyd;Dmelt2=Dmelt;avgfact2=avgfact;
load('3Mearth.mat',vars{:});
t3=t;T3=T;f_water3=f_water;qm3=qm;Db3=Db;uc3=uc;Dhyd3=Dhyd;Dmelt3=Dmelt;avgfact3=avgfact;
load('5Mearth.mat',vars{:});
t5=t;T5=T;f_water5=f_water;qm5=qm;Db5=Db;uc5=uc;Dhyd5=Dhyd;Dmelt5=Dmelt;avgfact5=avgfact;
clear('t','T','f_water','qm','Db','uc','qc','Dc','Dhyd','Dmelt','avgfact');

figure(1);
plot(t1/1e6,T1(:,1)/avgfact1,'b',t2/1e6,T2(:,1)/avgfact2,'b:',t3/1e6,T3(:,1)/avgfact3,'b-.',...
    t5/1e6,T5(:,1)/avgfact5,'b--');
title('Mantle Potential temperature');
legend('1 M_{E}','2 M_{E}','3 M_{E}','5 M_{E}');
xlabel('time (Myrs)');
ylabel('T_{p} (K)');

figure(2);
subplot(1,3,1);
plot(t1/1e6,Db1/1e3,'b',t2/1e6,Db2/1e3,'b:',t3/1e6,Db3/1e3,'b-.',t5/1e6,Db5/1e3,'b--');
title('Upper boundary layer');
legend('1 M_{E}','2 M_{E}','3 M_{E}','5 M_{E}');
xlabel('time (Myrs)');
ylabel('D_{u} (km)');
subplot(1,3,2);
plot(t1/1e6,Dhyd1/1e3,'b',t2/1e6,Dhyd2/1e3,'b:',t3/1e6,Dhyd3/1e3,'b-.',t5/1e6,Dhyd5/1e3,'b--');
title('Hydrated surface layer');
xlabel('time (Myrs)');
ylabel('D_{hyd} (km)');
subplot(1,3,3);
plot(t1/1e6,Dmelt1/1e3,'b',t2/1e6,Dmelt2/1e3,'b:',t3/1e6,Dmelt3/1e3,'b-.',t5/1e6,Dmelt5/1e3,'b--');
title('Melt layer');
xlabel('time (Myrs)');
ylabel('D_{melt} (km)');

figure(3);
plot(t1/1e6,qm1,'b',t2/1e6,qm2,'b:',t3/1e6,qm3,'b-.',t5/1e6,qm5,'b--');
title('Mantle heat flux');
legend('1 M_{E}','2 M_{E}','3 M_{E}','5 M_{E}');
xlabel('time (Myrs)');
ylabel('q_{m} (W/(m K)');

figure(4);
plot(t1/1e6,f_water1,'b',t2/1e6,f_water2,'b:',t3/1e6,f_water3,'b-.',t5/1e6,f_water5,'b--');
title('Mantle water abundance');
legend('1 M_{E}','2 M_{E}','3 M_{E}','5 M_{E}');
xlabel('time (Myrs)');
ylabel('X_{water}');

figure(5);
plot(t1/1e6,(T1(1,2)-T1(:,2))/1.39e21,'b',t2/1e6,(T2(1,2)-T2(:,2))/1.39e21,'b:',t3/1e6,(T3(1,2)-...
    T3(:,2))/1.39e21,'b-.',t5/1e6,(T5(1,2)-T5(:,2))/1.39e21,'b--');
title('Surface water abundance');
legend('1 M_{E}','2 M_{E}','3 M_{E}','5 M_{E}');
xlabel('time (Myrs)');
ylabel('water (OM)');




