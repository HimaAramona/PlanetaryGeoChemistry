%This script will calculate ocean areal coverage for the nominal model
%using the f_water abundance, and assuming a fixed ocean depth of 4500 m.

vars = {'t','T','Rp'};
load('1Mearth.mat',vars{:});
t1 = t;T1 = T;Rp1 = Rp;
load('2Mearth.mat',vars{:});
t2 = t;T2 = T;Rp2 = Rp;
load('3Mearth.mat',vars{:});
t3 = t;T3 = T;Rp3 = Rp;
load('5Mearth.mat',vars{:});
t5 = t;T5 = T;Rp5 = Rp;
clear t T

depth = 4500;
SA1 = 5.1e14;SA2 = 7.5e14;SA3 = 9.2e14;SA5 = 1.2e15;
rho = 1e3;
surfacewater1 = (T1(1,2)-T1(:,2));
surfacewater2 = (T2(1,2)-T2(:,2));
surfacewater3 = (T3(1,2)-T3(:,2));
surfacewater5 = (T5(1,2)-T5(:,2));
arealfrac1 = surfacewater1 / rho / depth / SA1;
arealfrac2 = surfacewater2 / rho / depth / SA2;
arealfrac3 = surfacewater3 / rho / depth / SA3;
arealfrac5 = surfacewater5 / rho / depth / SA5;

figure;
plot(t1/1e6,arealfrac1,'b',t2/1e6,arealfrac2,'b:',t3/1e6,arealfrac3,'b-.',...
    t5/1e6,arealfrac5,'b--');
title('Ocean areal coverage (assuming 4500 m depth)');
legend('1 M_{\oplus}','2 M_{\oplus}','3 M_{\oplus}','5 M_{\oplus}');
xlabel('time (Myrs)');
ylabel('ocean surface area fraction');


