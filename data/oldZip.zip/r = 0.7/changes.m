% Changes  from third:

% I was calculating the average factor relating potential temperature and
% average temeprature wrong!!!!FUCKK!!!! Now I need to redo ALLL of the
% figures. 

% 